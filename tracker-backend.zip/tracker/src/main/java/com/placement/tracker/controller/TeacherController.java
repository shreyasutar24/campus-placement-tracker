package com.placement.tracker.controller;

import com.placement.tracker.entity.Application;
import com.placement.tracker.entity.Student;
import com.placement.tracker.entity.Teacher;
import com.placement.tracker.repository.ApplicationRepository;
import com.placement.tracker.repository.StudentRepository;
import com.placement.tracker.repository.TeacherRepository;
import com.placement.tracker.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/teacher")
public class TeacherController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    // ---- Dashboard ----
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard(Authentication auth) {
        Teacher teacher = getTeacher(auth);
        Long deptId = teacher.getDepartment().getId();

        List<Student> students = studentRepository.findByDepartment_Id(deptId);
        long applied = students.stream()
                .flatMap(s -> applicationRepository.findByStudent(s).stream())
                .count();
        long selected = students.stream()
                .flatMap(s -> applicationRepository.findByStudent(s).stream())
                .filter(a -> a.getStatus().name().equals("SELECTED"))
                .count();

        Map<String, Object> stats = new HashMap<>();
        stats.put("department", teacher.getDepartment().getName());
        stats.put("totalStudents", students.size());
        stats.put("totalApplications", applied);
        stats.put("selected", selected);
        return ResponseEntity.ok(stats);
    }

    // ---- Department Students ----
    @GetMapping("/students")
    public ResponseEntity<List<Student>> getDepartmentStudents(Authentication auth) {
        Teacher teacher = getTeacher(auth);
        return ResponseEntity.ok(
                studentRepository.findByDepartment_Id(teacher.getDepartment().getId()));
    }

    // ---- Department Applications ----
    @GetMapping("/applications")
    public ResponseEntity<List<Application>> getDepartmentApplications(Authentication auth) {
        Teacher teacher = getTeacher(auth);
        List<Student> students = studentRepository.findByDepartment_Id(teacher.getDepartment().getId());
        List<Application> apps = students.stream()
                .flatMap(s -> applicationRepository.findByStudent(s).stream())
                .toList();
        return ResponseEntity.ok(apps);
    }

    // ---- Helper ----
    private Teacher getTeacher(Authentication auth) {
        String email = auth.getName();
        var user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return teacherRepository.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Teacher not found"));
    }
}