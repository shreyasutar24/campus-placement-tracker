package com.placement.tracker.controller;

import com.placement.tracker.dto.DepartmentRequest;
import com.placement.tracker.dto.OpportunityRequest;
import com.placement.tracker.dto.StudentRecordRequest;
import com.placement.tracker.dto.VerifyRequest;
import com.placement.tracker.entity.*;
import com.placement.tracker.repository.*;
import com.placement.tracker.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private OpportunityService opportunityService;

    @Autowired
    private ApplicationService applicationService;

    @Autowired
    private StudentRecordService studentRecordService;

    @Autowired
    private StudentService studentService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private OpportunityRepository opportunityRepository;

    // ---- Dashboard ----
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalStudents", studentRepository.count());
        stats.put("totalOpportunities", opportunityRepository.count());
        stats.put("totalApplications", applicationRepository.count());
        stats.put("pendingVerification", applicationService.getPendingVerification().size());
        return ResponseEntity.ok(stats);
    }

    // ---- Departments ----
    @PostMapping("/departments")
    public ResponseEntity<Department> createDepartment(@RequestBody DepartmentRequest request) {
        return ResponseEntity.ok(departmentService.createDepartment(request.getName(), request.getCode()));
    }

    @GetMapping("/departments")
    public ResponseEntity<List<Department>> getAllDepartments() {
        return ResponseEntity.ok(departmentService.getAllDepartments());
    }

    @DeleteMapping("/departments/{id}")
    public ResponseEntity<String> deleteDepartment(@PathVariable Long id) {
        departmentService.deleteDepartment(id);
        return ResponseEntity.ok("Department deleted.");
    }

    // ---- Student Records (pre-approved list) ----
    @PostMapping("/student-records")
    public ResponseEntity<StudentRecord> addStudentRecord(@RequestBody StudentRecordRequest request) {
        return ResponseEntity.ok(studentRecordService.addStudentRecord(
                request.getRollNumber(), request.getUniversityNumber(),
                request.getFullName(), request.getDepartmentId(),
                request.getPassingYear(), request.getEmail()));
    }

    @GetMapping("/student-records")
    public ResponseEntity<List<StudentRecord>> getAllStudentRecords() {
        return ResponseEntity.ok(studentRecordService.getAllStudentRecords());
    }

    // ---- Students ----
    @GetMapping("/students")
    public ResponseEntity<List<Student>> getAllStudents() {
        return ResponseEntity.ok(studentService.getAllStudents());
    }

    // ---- Opportunities ----
    @PostMapping("/opportunities")
    public ResponseEntity<Opportunity> createOpportunity(@RequestBody OpportunityRequest request,
                                                          Authentication auth) {
        String email = auth.getName();
        User createdBy = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(opportunityService.createOpportunity(
                request.getCompanyName(), request.getJobRole(), request.getPackageLpa(),
                request.getLocation(), request.getApplyLink(), request.getLastDate(),
                request.getMinCgpa(), request.getMin10thPercentage(), request.getMin12thPercentage(),
                request.isNoActiveBacklogAllowed(), request.getRequiredSkills(),
                request.getDescription(), request.getAllowedDepartmentIds(), createdBy.getId()));
    }

    @GetMapping("/opportunities")
    public ResponseEntity<List<Opportunity>> getAllOpportunities() {
        return ResponseEntity.ok(opportunityService.getAllOpportunities());
    }

    @DeleteMapping("/opportunities/{id}")
    public ResponseEntity<String> deleteOpportunity(@PathVariable Long id) {
        opportunityService.deleteOpportunity(id);
        return ResponseEntity.ok("Opportunity deleted.");
    }

    // ---- Verification ----
    @GetMapping("/verify")
    public ResponseEntity<List<Application>> getPendingVerification() {
        return ResponseEntity.ok(applicationService.getPendingVerification());
    }

    @PutMapping("/verify/{applicationId}")
    public ResponseEntity<Application> verifyApplication(@PathVariable Long applicationId,
                                                          @RequestBody VerifyRequest request) {
        return ResponseEntity.ok(applicationService.verifyApplication(applicationId, request.isApprove()));
    }
}